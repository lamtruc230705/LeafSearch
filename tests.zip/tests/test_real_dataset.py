"""Smoke tests cho bộ ảnh thật được tích hợp; tự skip ở bản mã nguồn không có ảnh.

Các kiểm thử thuật toán chi tiết dùng tests/test_pipeline.py với dữ liệu nhỏ.
Tệp này bổ sung kiểm tra môi trường nghiệm thu 1.685 PNG/SQLite thật.
"""

from pathlib import Path

from fastapi.testclient import TestClient
import pytest

from backend.config import SETTINGS
from backend.db import connect
from backend.main import app


DATA_AVAILABLE = SETTINGS.database.is_file() and SETTINGS.images_dir.is_dir()
pytestmark = pytest.mark.skipif(not DATA_AVAILABLE, reason="Chưa nhập ZIP ảnh chính thức")


def test_full_dataset_metadata_and_quality_api():
    client = TestClient(app)
    health = client.get("/api/health")
    assert health.status_code == 200
    actual = health.json()
    assert actual["ready"] and actual["total_images"] == 1685
    assert actual["categories"] == 32 and actual["vector_count"] == 6740
    assert (actual["gallery"], actual["validation"], actual["test"]) == (1345, 170, 170)
    quality = client.get("/api/quality")
    assert quality.status_code == 200
    assert quality.json()["review_count"] >= 0
    assert client.get("/api/quality/near-duplicates.csv").status_code in (200, 404)


def test_real_test_query_searches_gallery_only():
    with connect(SETTINGS.database) as con:
        item = con.execute(
            "SELECT file_name,relative_path FROM images WHERE split='test' ORDER BY image_id LIMIT 1"
        ).fetchone()
    content = (SETTINGS.images_dir / item["relative_path"]).read_bytes()
    response = TestClient(app).post(
        "/api/search", files={"file": (item["file_name"], content, "image/png")},
    )
    assert response.status_code == 200, response.text
    results = response.json()["results"]
    assert len(results) == 5
    assert [x["distance_total"] for x in results] == sorted(x["distance_total"] for x in results)
    with connect(SETTINGS.database) as con:
        for entry in results:
            r = con.execute("SELECT split FROM images WHERE image_id=?", (entry["image_id"],)).fetchone()
            assert r["split"] == "gallery"
