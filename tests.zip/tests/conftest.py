"""Fixture kiểm thử: lá nhân tạo KHÔNG được coi là dữ liệu nghiên cứu thật."""
from pathlib import Path

import cv2
import numpy as np
import pytest
from fastapi.testclient import TestClient

from backend.config import Settings
from backend.main import create_app
from backend.tools.import_dataset import import_dataset


@pytest.fixture(scope='module')
def sample_dataset(tmp_path_factory):
    """Tạo 15 ảnh PNG 512x512: 3 nhóm, mỗi nhóm 5 ảnh khác nhau."""
    root = tmp_path_factory.mktemp('leafsearch-test')
    inputs = root / 'input'; inputs.mkdir()
    for group in range(1, 4):
        for index in range(1, 6):
            canvas = np.full((512, 512, 3), 255, dtype=np.uint8)
            hue = (group * 23 + index * 2) % 179
            pixel = np.uint8([[[hue, 150 + index * 5, 100 + index * 20]]])
            color = tuple(int(x) for x in cv2.cvtColor(pixel, cv2.COLOR_HSV2BGR)[0, 0])
            cv2.ellipse(canvas, (256, 248), (36 + 32*group, 150 - 16*group + index*3),
                        (group*13 + index*6), 0, 360, color, -1)
            cv2.line(canvas, (250, 150), (256, 365), (24, 92, 35), 3)
            assert cv2.imwrite(str(inputs / f'{group}.{index}.png'), canvas)
    database = root / 'leafsearch.sqlite'
    images = root / 'images'
    summary = import_dataset(inputs, database, images, strict=False)
    return root, summary, database, images


@pytest.fixture(scope='module')
def client(sample_dataset):
    _, _, db, images = sample_dataset
    settings = Settings(database=db, images_dir=images)
    with TestClient(create_app(settings)) as browser:
        yield browser
