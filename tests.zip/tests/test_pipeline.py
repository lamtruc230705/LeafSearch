"""Các test tích hợp API, DB, importer và so khớp vector 560 chiều."""

from io import BytesIO
from pathlib import Path
import sqlite3
import zipfile

import numpy as np
import pytest

from backend.db import connect, decode_vector
from backend.tools.import_dataset import _read_metadata, make_splits, import_dataset
from backend.vision.features import DIMENSIONS, ORDER


def test_import_and_schema(sample_dataset):
    _, summary, database, images = sample_dataset
    assert summary['images'] == 15
    assert summary['groups'] == 3
    assert summary['features'] == 60
    assert summary['gallery'] >= 5
    with connect(database) as con:
        assert con.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert con.execute('PRAGMA foreign_key_check').fetchall() == []
        assert con.execute('SELECT COUNT(*) FROM features').fetchone()[0] == 60
        for row in con.execute('SELECT * FROM features'):
            assert row['dimension'] == DIMENSIONS[row['feature_group']]
            assert np.isfinite(decode_vector(row['vector'], row['dimension'])).all()
        # feature_stats PHẢI chỉ dùng gallery.
        for group in ORDER:
            row = con.execute('SELECT * FROM feature_stats WHERE feature_group=?', (group,)).fetchone()
            gallery = con.execute('SELECT f.vector FROM features f JOIN images i ON i.image_id=f.image_id '
                                  'WHERE i.split=\'gallery\' AND f.feature_group=?', (group,)).fetchall()
            vectors = np.stack([decode_vector(x['vector'], DIMENSIONS[group]) for x in gallery])
            stored_mean = decode_vector(row['mean_vector'], row['dimension'])
            assert np.allclose(stored_mean, vectors.mean(axis=0), rtol=1e-3, atol=1e-4)
    assert len(list(images.rglob('*.png'))) == 15


def test_health_dashboard_and_categories(client):
    response = client.get('/api/health')
    assert response.status_code == 200
    data = response.json()
    assert data['ready'] is True and data['vector_count'] == 60
    assert data['categories'] == 3
    categories = client.get('/api/categories').json()['items']
    assert len(categories) == 3
    assert all(x['thumbnail_url'].startswith('/api/images/') for x in categories)
    assert sum(x['image_count'] for x in categories) == 15
    assert 'LeafSearch PTIT' in client.get('/').text
    assert client.get('/assets/app.js').status_code == 200


def test_library_and_processed_image(client):
    collection = client.get('/api/images', params={'group_id': '01', 'page_size': 2}).json()
    assert collection['total'] == 5 and len(collection['items']) == 2
    image_id = collection['items'][0]['image_id']
    detail = client.get(f'/api/images/{image_id}').json()
    assert set(detail['features']) == set(ORDER)
    for group in ORDER:
        assert detail['features'][group]['dimension'] == DIMENSIONS[group]
    for path in (f'/api/images/{image_id}/file', f'/api/images/{image_id}/processed/mask',
                 f'/api/images/{image_id}/processed/normalized'):
        response = client.get(path)
        assert response.status_code == 200 and response.headers['content-type'].startswith('image/png')
        assert response.content.startswith(b'\x89PNG')
    assert client.get('/api/images/999999').status_code == 404


def test_image_search_real(client, sample_dataset):
    root = sample_dataset[0]
    image_blob = (root / 'input' / '2.1.png').read_bytes()
    response = client.post('/api/search', files={'file': ('query.png', image_blob, 'image/png')},
                           data={'color': '25', 'shape': '45', 'ridge': '15', 'texture': '15'})
    assert response.status_code == 200, response.text
    result = response.json()
    assert len(result['results']) == 5
    distances = [x['distance_total'] for x in result['results']]
    assert distances == sorted(distances)
    assert result['query']['mask_image'].startswith('data:image/png;base64,')
    assert all(row['image_url'].startswith('/api/images/') for row in result['results'])
    # Mọi ảnh trả về PHẢI thuộc gallery, không lấy validation/test.
    with connect(sample_dataset[2]) as con:
        for row in result['results']:
            split = con.execute('SELECT split FROM images WHERE image_id=?',
                                (row['image_id'],)).fetchone()['split']
            assert split == 'gallery'
    assert client.post('/api/search', files={'file': ('test.txt', b'abc', 'text/plain')}).status_code == 415


def test_evaluation_runs_real(client):
    resp = client.post('/api/evaluate', json={'split': 'test',
                   'weights': {'color': .25, 'shape': .45, 'ridge': .15, 'texture': .15}})
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert data['metrics']['queries'] == 3
    for k in ['accuracy_at_1', 'precision_at_5', 'mrr_at_5']:
        assert 0 <= data['metrics'][k] <= 1
    assert client.get('/api/evaluations/latest').status_code == 200
    assert client.get('/api/evaluations/99999').status_code == 404
    assert client.post('/api/evaluate', json={'split': 'gallery'}).status_code == 400


def test_import_strict_rejects_unverified_small_dataset(sample_dataset, tmp_path):
    input_dir = sample_dataset[0] / 'input'
    with pytest.raises(ValueError, match='Dataset không khớp báo cáo'):
        import_dataset(input_dir, tmp_path / 'new.sqlite', tmp_path / 'images', strict=True)


def test_duplicate_detection(tmp_path):
    from PIL import Image
    import numpy as np
    im = Image.new('RGB', (512, 512), (200, 240, 200))
    out = BytesIO(); im.save(out, format='PNG')
    data = out.getvalue()
    assert _read_metadata('2.1.png', data)[0] == '02'
    with pytest.raises(ValueError, match='Tên sai mẫu'):
        _read_metadata('evil.png', data)
    with pytest.raises(ValueError, match='512×512'):
        buf = BytesIO(); Image.new('RGB', (150, 100)).save(buf, format='PNG')
        _read_metadata('2.1.png', buf.getvalue())


def test_strict_counts_1345_170_170():
    """Không cần ảnh gốc để kiểm tra thuật toán chia 32 nhóm đúng báo cáo."""
    from collections import Counter
    from backend.tools.import_dataset import Record, EXPECTED_COUNTS
    fake = [Record(f'{int(g)}.{n}.png', g, '', '', '', 512, 512)
            for g, amount in EXPECTED_COUNTS.items() for n in range(1, amount + 1)]
    splits = make_splits(fake, strict=True)
    counts = Counter(splits.values())
    assert counts == {'gallery': 1345, 'validation': 170, 'test': 170}
    assert Counter(splits[r.file_name] for r in fake if r.group_id == '01')['gallery'] == 4
    assert Counter(splits[r.file_name] for r in fake if r.group_id == '25')['gallery'] == 3
    assert make_splits(fake, strict=True) == splits  # deterministic seed


def test_near_duplicate_audit(sample_dataset, tmp_path):
    from backend.tools.audit_near_duplicates import audit_near_duplicates
    _, _, database, images_dir = sample_dataset
    csv_path = tmp_path / 'audit.csv'
    pairs = audit_near_duplicates(database, images_dir, threshold=6, output=csv_path)
    assert csv_path.exists()
    assert all(0 <= row['hamming_distance'] <= 6 for row in pairs)
    assert 'cross_split' in csv_path.read_text(encoding='utf-8-sig')


def test_nested_zip_removes_exact_duplicate(sample_dataset, tmp_path):
    """ZIP có thư mục bao ngoài và một bản sao cùng pixel: tự bỏ bản sao."""
    source = sample_dataset[0] / 'input'
    archive = tmp_path / 'bo_anh_nested.zip'
    with zipfile.ZipFile(archive, mode='w', compression=zipfile.ZIP_DEFLATED) as z:
        for f in source.iterdir():
            z.write(f, arcname='Bo_du_lieu_thu_thap/Anh/' + f.name)
        # Nội dung trùng pixel với nhóm 01 nhưng tên khác: chỉ giữ bản đại diện.
        z.write(source / '1.1.png', arcname='Bo_du_lieu_thu_thap/Anh/1.99.png')
    result = import_dataset(archive, tmp_path / 'new.sqlite', tmp_path / 'images', strict=False)
    assert result['source_png'] == 16
    assert result['images'] == 15
    assert result['removed_duplicates'] == 1
    assert (tmp_path / 'removed_duplicates.json').exists()


def test_import_when_server_already_created_empty_schema(sample_dataset, tmp_path):
    """Người học mở website trước khi import: schema rỗng KHÔNG cản lần nhập đầu."""
    from backend.db import initialize
    folder = tmp_path / "initial_server"
    folder.mkdir()
    db = folder / "leafsearch.sqlite"
    images = folder / "images"
    initialize(db)  # FastAPI đã tạo schema, không có dòng dữ liệu.
    images.mkdir()  # Có thể tồn tại thư mục ảnh rỗng.
    summary = import_dataset(sample_dataset[0] / "input", db, images, strict=False)
    assert summary["images"] == 15
    assert not (folder / "leafsearch.sqlite.previous").exists()
    with connect(db) as con:
        assert con.execute("SELECT COUNT(*) FROM images").fetchone()[0] == 15
    # Không được ghi đè dữ liệu thật nếu không cho phép.
    with pytest.raises(FileExistsError, match="Đích đã có dữ liệu"):
        import_dataset(sample_dataset[0] / "input", db, images, strict=False)


def test_quality_api_without_audit(client):
    """DB nhỏ vẫn hiển thị ảnh cần kiểm tra; audit chưa chạy không hiện số giả."""
    res = client.get('/api/quality')
    assert res.status_code == 200
    payload = res.json()
    assert payload['audit_available'] is False
    assert payload['candidate_pairs'] is None
    assert payload['cross_split_pairs'] is None
    assert client.get('/api/quality/near-duplicates.csv').status_code == 404
